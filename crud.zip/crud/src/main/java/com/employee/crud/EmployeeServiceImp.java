package com.employee.crud;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class EmployeeServiceImp implements EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Override
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    @Override
    public Employee getEmployeeById(Long id) {
        return employeeRepository.findById(id).orElse(null);
    }

    @Override
    public Employee createEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    @Override
    public Employee updateEmployee(Long id, Employee employee) { // Changed method name to match interface
        Optional<Employee> existingEmployeeOpt = employeeRepository.findById(id);
        
        if (existingEmployeeOpt.isPresent()) {
            Employee existingEmployee = existingEmployeeOpt.get();
            
            if (Objects.nonNull(employee.getName()) && !employee.getName().trim().isEmpty()) {
                existingEmployee.setName(employee.getName());
            }
            
            if (Objects.nonNull(employee.getDoj()) && !employee.getDoj().toString().trim().isEmpty()) {
                existingEmployee.setDoj(employee.getDoj());
            }
            
            if (Objects.nonNull(employee.getSalary()) && employee.getSalary() != 0) {
                existingEmployee.setSalary(employee.getSalary());
            }
            
            if (Objects.nonNull(employee.getStatus()) && employee.getStatus() != -1) {
                existingEmployee.setStatus(employee.getStatus());
            }

            return employeeRepository.save(existingEmployee);
        }

        return null; // Or throw an exception if preferred
    }

    @Override
    public void deleteEmployee(Long id) {
        employeeRepository.deleteById(id);
    }
}
